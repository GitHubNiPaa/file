<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic Calculator in PHP</title>
</head>
<body>

<header>
    <h1>Basic Calculator in PHP</h1>
</header>

<form id="student" name="student" method="POST" action="calc.php">
    <label for="num1">NUM1:</label>
    <input type="number" name="num1" id="num1"><br>
    <label for="num2">NUM2:</label>
    <input type="number" name="num2" id="num2"><br>

    <select name="operator" id="operator">
        <option value="total">Addition</option>
        <option value="difference">Subtraction</option>
        <option value="product">Multiplication</option>
        <option value="quotient">Division</option>
    </select>

    <input type="submit" name="answer" id="answer" value="Calculate">
</form>
    
</body>
</html>
