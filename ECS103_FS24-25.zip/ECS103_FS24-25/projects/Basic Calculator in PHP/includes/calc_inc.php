<?php
    class Calc{
        public $NUM1, $NUM2, $operator;

        public function __construct($NUM1, $NUM2, $operator) {
            $this-> NUM1=$NUM1;
            $this-> NUM2=$NUM2;
            $this-> operator=$operator;
        }

        public function calcMethod() {
            switch($this-> operator) {
                case 'total':
                    $result=$this-> NUM1 + $this-> NUM2;
                    break;
                case 'difference':
                    $result=$this-> NUM1 - $this-> NUM2;
                    break;
                case 'product':
                    $result=$this-> NUM1 * $this-> NUM2;
                    break;
                case 'quotient':
                    $result=$this-> NUM1 / $this-> NUM2;
                    break;
                default:
                    $result="Invalid result.";
            }
            return $result;
        }
    }
?>