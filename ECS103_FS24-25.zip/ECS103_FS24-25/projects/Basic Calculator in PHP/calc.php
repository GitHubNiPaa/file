<?php

include './includes/calc_inc.php';

    $NUM1 = $_POST['num1'];
    $NUM2 = $_POST['num2'];
    $operator = $_POST['operator'];

    $calculator = new Calc($NUM1, $NUM2, $operator);
        echo $calculator -> calcMethod();
?>