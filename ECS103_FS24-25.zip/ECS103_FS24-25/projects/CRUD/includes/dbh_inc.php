<?php
    class dbHandle {
        private $serverName, $username, $password, $dbName;
        
        function connect() {
            $this-> serverName="localhost";
            $this-> username="root";
            $this-> password="";
            $this-> dbName="dbaccount";

            $connection=mysqli($this-> serverName, $this-> username, $this-> password, $this-> dbName);

            return $connection;
        }
    }

?>