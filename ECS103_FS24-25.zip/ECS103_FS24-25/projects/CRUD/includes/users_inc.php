<?php
    class ViewUser {
        public function showAllUsers() {
            

        }
    }
?>